package Com.kite.qa.pages;

import java.io.IOException;

import Com.kite.qa.base.TestBase;

public class OrdersPage extends TestBase {

	public OrdersPage() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

}
