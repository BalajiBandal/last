package Com.kite.qa.pages;

import java.io.IOException;

import Com.kite.qa.base.TestBase;

public class HoldingPage extends TestBase{

	public HoldingPage() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

}
